import { Image, ScrollView, StyleSheet, Text, View } from 'react-native';

export default function App() {
  return (
    <ScrollView contentContainerStyle={styles.container}>
      {/* Imagen personal */}
      <Image
        source={require('./assets/foto.jpg')} // Cambia por tu foto
        style={styles.image}
      />

      {/* Nombre */}
      <Text style={styles.name}>Luis Jamon Belman Pérez</Text>

      {/* Biografía */}
      <Text style={styles.bio}>
        Hola, soy Luis y soy de México. Me gusta la tecnología, el desarrollo de software y aprender cosas nuevas.
        Los fines de semana me gusta salir con amigos, explorar nuevos lugares y ver películas.
      </Text>

      {/* Gustos */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Mis gustos</Text>
        <Text style={styles.sectionText}>🎮 Videojuegos</Text>
        <Text style={styles.sectionText}>📚 Leer libros de ciencia ficción</Text>
        <Text style={styles.sectionText}>🚀 Aprender sobre programación y tecnología</Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 20,
    alignItems: 'center',
    backgroundColor: '#f3f4f6',
  },
  image: {
    width: 200,
    height: 200,
    borderRadius: 100,
    borderWidth: 4,
    borderColor: '#ff6ec7',
    marginBottom: 20,
  },
  name: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#ff4da6',
    marginBottom: 10,
  },
  bio: {
    fontSize: 16,
    textAlign: 'center',
    marginBottom: 20,
    color: '#333',
  },
  section: {
    backgroundColor: '#fff',
    padding: 15,
    borderRadius: 10,
    width: '100%',
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowOffset: { width: 0, height: 3 },
    shadowRadius: 5,
    elevation: 3,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
    color: '#ff4da6',
  },
  sectionText: {
    fontSize: 16,
    marginBottom: 5,
  },
});