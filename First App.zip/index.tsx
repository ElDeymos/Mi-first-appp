import { Image, ScrollView, StyleSheet, Text, View } from 'react-native';

export default function App() {
  return (
    <ScrollView contentContainerStyle={styles.container}>
      {/* Imagen personal */}
      <Image
        source={require('../../assets/images/hola.jpg')} // Cambia por tu foto
        style={styles.image}
      />

      {/* Nombre */}
      <Text style={styles.name}>Miguel Ángel Belman Mejía</Text>

      {/* Biografía */}
      <Text style={styles.bio}>
        Hola, soy Miguel Belman y soy de México. Me gusta la tecnología, aprender y hacer mucho ejercicio. Trabajo, en las tardes en una cafetería.
      </Text>

      {/* Gustos */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Mis gustos</Text>
        <Text style={styles.sectionText}>🎮 Videojuegos</Text>
        <Text style={styles.sectionText}>🎧 Escuchar música</Text>
        <Text style={styles.sectionText}>🏋️‍♂️ Hacer ejercicio</Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 20,
    flex:1,
    alignItems: 'center',
    backgroundColor: '#f3f4f6',   
    justifyContent: 'center', 
  },
  image: {
    width: 200,
    height: 200,
    borderRadius: 100,
    borderWidth: 4,
    borderColor: 'green',
    marginBottom: 20,
  },
  name: {
    fontSize: 24,
    fontWeight: 'bold',
    color: 'green',
    marginBottom: 10,
  },
  bio: {
    fontSize: 16,
    textAlign: 'center',
    marginBottom: 20,
    color: '#333',
  },
  section: {
    backgroundColor: '#fff',
    padding: 15,
    borderRadius: 10,
    width: '100%',
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowOffset: { width: 0, height: 3 },
    shadowRadius: 5,
    elevation: 3,
    verticalAlign:'middle'
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
    color: 'green',
  },
  sectionText: {
    fontSize: 16,
    marginBottom: 5,
  },
});