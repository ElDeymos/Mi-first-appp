
import { Text, View, Image } from 'react-native';
import styles from './styles/styles';

export default App = () => {
  return (
    <View style={styles.container}>
      <View style={styles.box}>
        <Text style={styles.title}>Hola mundo!</Text>
      </View>

      <View style={styles.boxImage}>
        <Image 
          source={require('./assets/dinero.png')} 
          style={{ width: 150, height: 150 }} 
        />
        <Text>Hola, soy Belman y esta es mi primera app en React Native.</Text>
      </View>
    </View>
  );
};




